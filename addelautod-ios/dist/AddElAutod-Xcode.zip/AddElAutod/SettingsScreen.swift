import SwiftUI
import PhotosUI
import UIKit

/// Autosweb /beallitasok.html?szekcio=fiok — Fiók szerkesztése (személyes adatok)
struct SettingsScreen: View {
    @EnvironmentObject private var profile: ProfileStore
    var onClose: () -> Void

    @State private var toast: String?
    @State private var currentPassword = ""
    @State private var newPassword = ""
    @State private var newPasswordConfirm = ""
    @State private var cityLookupBusy = false
    @State private var lastLookedUpPostal = ""
    @State private var photoItem: PhotosPickerItem?

    var body: some View {
        VStack(spacing: 0) {
            ScreenHeader(title: "Beállítások", subtitle: "Fiók szerkesztése", onBack: onClose)
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    personalCard
                    searchAreaCard
                    passwordCard
                    notifyCard
                    dangerCard
                }
                .padding(16)
                .padding(.bottom, 32)
            }
        }
        .background(AppTheme.bgGrouped)
        .alert("Beállítások", isPresented: Binding(
            get: { toast != nil },
            set: { if !$0 { toast = nil } }
        )) {
            Button("OK", role: .cancel) { toast = nil }
        } message: {
            Text(toast ?? "")
        }
    }

    private var personalCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Személyes adatok")
                .font(.headline)

            HStack(alignment: .center, spacing: 14) {
                ProfileAvatarView(
                    image: profile.avatarImage,
                    letter: profile.profile.avatarLetter,
                    size: 72
                )

                VStack(alignment: .leading, spacing: 8) {
                    Text(profile.profile.displayName)
                        .font(.body.weight(.semibold))

                    HStack(spacing: 8) {
                        PhotosPicker(selection: $photoItem, matching: .images, photoLibrary: .shared()) {
                            Text(profile.avatarImage == nil ? "Feltöltés" : "Csere")
                                .font(.caption.weight(.semibold))
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .foregroundStyle(.white)
                                .background(AppTheme.accent)
                                .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                        }
                        if profile.avatarImage != nil {
                            Button("Törlés") {
                                profile.clearAvatar()
                                toast = "Profilkép törölve."
                            }
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.red)
                        }
                    }
                }

                Spacer(minLength: 8)

                VStack(spacing: 4) {
                    ProfileQRView(profile: profile.profile, size: 72)
                    Text("Profil QR")
                        .font(.caption2)
                        .foregroundStyle(AppTheme.textSecondary)
                }
            }
            .onChange(of: photoItem) { _, item in
                guard let item else { return }
                Task {
                    if let data = try? await item.loadTransferable(type: Data.self),
                       let image = UIImage(data: data) {
                        profile.setAvatar(image)
                        toast = "Profilkép mentve."
                    } else {
                        toast = "A kép betöltése sikertelen."
                    }
                    photoItem = nil
                }
            }

            HStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 6) {
                    fieldLabel("Vezetéknév")
                    TextField("", text: $profile.profile.lastName)
                        .textFieldStyle(.roundedBorder)
                        .textContentType(.familyName)
                }
                VStack(alignment: .leading, spacing: 6) {
                    fieldLabel("Keresztnév")
                    TextField("", text: $profile.profile.firstName)
                        .textFieldStyle(.roundedBorder)
                        .textContentType(.givenName)
                }
            }

            fieldLabel("Utca, házszám")
            TextField("", text: $profile.profile.street)
                .textFieldStyle(.roundedBorder)
                .textContentType(.streetAddressLine1)

            postalAndCityRow

            fieldLabel("Ország")
            TextField("", text: $profile.profile.country)
                .textFieldStyle(.roundedBorder)
                .textContentType(.countryName)

            fieldLabel("Telefon")
            TextField("+36 …", text: $profile.profile.phone)
                .textFieldStyle(.roundedBorder)
                .keyboardType(.phonePad)
                .textContentType(.telephoneNumber)

            fieldLabel("Email")
            TextField("email@pelda.hu", text: $profile.profile.email)
                .textFieldStyle(.roundedBorder)
                .keyboardType(.emailAddress)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .textContentType(.emailAddress)
                .disabled(true)

            fieldLabel("Fióktípus")
            Picker("", selection: $profile.profile.accountType) {
                Text("Magánszemély").tag("private")
                Text("Vállalkozás (nem kereskedő)").tag("business")
                Text("Autókereskedő").tag("dealer")
            }
            .pickerStyle(.menu)

            if profile.profile.accountType == "business" || profile.profile.accountType == "dealer" {
                fieldLabel(profile.profile.accountType == "dealer" ? "Kereskedés neve" : "Cégnév")
                TextField("", text: $profile.profile.company)
                    .textFieldStyle(.roundedBorder)
                    .textContentType(.organizationName)
            }

            Button {
                Task {
                    if let err = await profile.saveProfileToServer() {
                        toast = err
                    } else {
                        toast = "Adatok mentve (web + app)."
                    }
                }
            } label: {
                Text("Adatok mentése")
                    .font(.body.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .foregroundStyle(.white)
                    .background(AppTheme.accent)
                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppTheme.bgElevated)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    /// Gyors kategória kereséshez: irányítószám + km-sugár
    private var searchAreaCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Keresési körzet")
                .font(.headline)
            Text("A gyorsikonok (Diesel, Benzin…) ezzel az irányítószámmal és km-sugárral szűrnek.")
                .font(.footnote)
                .foregroundStyle(AppTheme.textSecondary)

            postalAndCityRow

            fieldLabel("Sugár (km)")
            Picker("Sugár", selection: $profile.profile.searchRadiusKm) {
                ForEach([5, 10, 15, 20, 30, 50, 75, 100], id: \.self) { km in
                    Text("\(km) km").tag(km)
                }
            }
            .pickerStyle(.wheel)
            .frame(height: 120)

            Button {
                profile.save()
                toast = "Keresési körzet mentve."
            } label: {
                Text("Körzet mentése")
                    .font(.body.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .foregroundStyle(.white)
                    .background(AppTheme.accent)
                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppTheme.bgElevated)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    private var passwordCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Jelszó módosítása")
                .font(.headline)
            SecureField("Jelenlegi jelszó", text: $currentPassword)
                .textFieldStyle(.roundedBorder)
            SecureField("Új jelszó", text: $newPassword)
                .textFieldStyle(.roundedBorder)
            SecureField("Új jelszó mégegyszer", text: $newPasswordConfirm)
                .textFieldStyle(.roundedBorder)
            Button {
                Task {
                    if let err = await profile.changePassword(
                        current: currentPassword,
                        newPassword: newPassword,
                        confirm: newPasswordConfirm
                    ) {
                        toast = err
                        return
                    }
                    currentPassword = ""
                    newPassword = ""
                    newPasswordConfirm = ""
                    toast = "Jelszó mentve (web + app)."
                }
            } label: {
                Text("Jelszó mentése")
                    .font(.body.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .foregroundStyle(.white)
                    .background(AppTheme.accent)
                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppTheme.bgElevated)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    private var notifyCard: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Hírlevél és értesítések")
                .font(.headline)
                .padding(.bottom, 8)

            Toggle("Üzenetek e-mailben", isOn: $profile.profile.notifyMessages)
                .tint(.green)
            Toggle("Parkoló: árváltozás", isOn: $profile.profile.notifyFavorites)
                .tint(.green)
            Toggle("Érdeklődések", isOn: $profile.profile.notifyInterests)
                .tint(.green)
            Toggle("Hírlevél / tippek (marketing)", isOn: $profile.profile.notifyNewsletter)
                .tint(.green)

            Button {
                profile.save()
                toast = "Értesítési beállítások mentve."
            } label: {
                Text("Értesítések mentése")
                    .font(.body.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .foregroundStyle(.white)
                    .background(AppTheme.accent)
                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
            }
            .padding(.top, 8)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppTheme.bgElevated)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    private var dangerCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Kijelentkezés")
                .font(.headline)
            Button {
                Task { await profile.logout() }
            } label: {
                Text("Kijelentkezés")
                    .font(.body.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
            }

            Text("Fiók törlése")
                .font(.headline)
                .padding(.top, 8)
            Text("A törlés végleges a közös szerveren is (web + app).")
                .font(.subheadline)
                .foregroundStyle(AppTheme.textSecondary)
            Button(role: .destructive) {
                Task {
                    if let err = await profile.deleteAccount() {
                        toast = err
                    } else {
                        onClose()
                    }
                }
            } label: {
                Text("Fiók törlése")
                    .font(.body.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppTheme.bgElevated)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    private var postalAndCityRow: some View {
        HStack(alignment: .top, spacing: 10) {
            VStack(alignment: .leading, spacing: 6) {
                fieldLabel("Irányítószám")
                TextField("7083", text: $profile.profile.postalCode)
                    .textFieldStyle(.roundedBorder)
                    .textContentType(.postalCode)
                    .keyboardType(.numberPad)
                    .frame(width: 96)
                    .onChange(of: profile.profile.postalCode) { _, newValue in
                        let digits = String(newValue.filter(\.isNumber).prefix(4))
                        if digits != newValue {
                            profile.profile.postalCode = digits
                            return
                        }
                        Task { await lookupCityFromPostal() }
                    }
            }

            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 6) {
                    fieldLabel("Település")
                    if cityLookupBusy {
                        ProgressView()
                            .scaleEffect(0.7)
                    }
                }
                TextField("automatikus", text: $profile.profile.city)
                    .textFieldStyle(.roundedBorder)
                    .textContentType(.addressCity)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .task {
            await lookupCityFromPostal()
        }
    }

    private func lookupCityFromPostal() async {
        let digits = String(profile.profile.postalCode.filter(\.isNumber).prefix(4))
        guard digits.count == 4 else { return }
        guard digits != lastLookedUpPostal else { return }
        cityLookupBusy = true
        defer { cityLookupBusy = false }
        if let city = await PartnerRecommendationsClient.lookupCity(postalCode: digits) {
            lastLookedUpPostal = digits
            profile.profile.city = city
            profile.profile.postalCode = digits
        }
    }

    private func fieldLabel(_ text: String) -> some View {
        Text(text)
            .font(.caption.weight(.semibold))
            .foregroundStyle(AppTheme.textSecondary)
    }
}
